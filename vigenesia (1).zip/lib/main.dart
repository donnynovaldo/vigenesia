import 'package:flutter/material.dart';
import '/../Screens/Login.dart';

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Login(),
    ));
